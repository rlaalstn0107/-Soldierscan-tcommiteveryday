<!DOCTYPE html>
<html>
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>
    <h1>Comparison Operators&amp;
    Boolean data type </h1>
  </body>
  <?php
  var_dump(1==1);
  var_dump(2+14);
  var_dump(1.523);
   ?>
</html>
