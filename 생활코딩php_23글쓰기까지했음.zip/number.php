<!doctype html>
<html>
<body>
  <h1>Number & Operator</h1>
  <h2>1+1</h2>
<?php
print(1);
 ?>
 <h1>2-1</h1>
 <?php
 echo 2-1;
  ?>
</body>
</html>
