<!doctype html>
<html>
<body>
<?php
echo "Hello \"w\"ord";
 ?>
 <h2>concatenation operator </h2>
 <?php
 echo "minsu"." is"." go up"
  ?>
  <h2>String length function</h2>
  <?php
  echo strlen("Hello world");

  ?>

</body>
</html>
