<!DOCTYPE html>
<html lang="en" dir="ltr">
  <head>
    <meta charset="utf-8">
    <title></title>
  </head>
  <body>

    안녕하세요. <?php echo $_GET['address'];?>에 사시는 <?php echo $_GET['name'];?>님

  </body>
</html>
