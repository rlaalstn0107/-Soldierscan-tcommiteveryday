# -Soldierscan-tcommiteveryday
 I'm cut off my company and on duty.
